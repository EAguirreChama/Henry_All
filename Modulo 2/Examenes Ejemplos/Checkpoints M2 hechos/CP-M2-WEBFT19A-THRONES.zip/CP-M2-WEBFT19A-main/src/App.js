import { Route } from 'react-router-dom';
import Nav from './components/Nav/Nav';

function App() {
  return (
    <div className="App">

    </div>
  );
};

export default App;
