import React, { Component } from 'react'

// CUIDADOOOO. SI O SI CLASS COMPONENT! SE ROMPEN LOS TEST EN CASO CONTRARIO!!
class Nav extends Component {

    render() {
        return (
            <div>

            </div>
        );
    };
};

export default Nav;
