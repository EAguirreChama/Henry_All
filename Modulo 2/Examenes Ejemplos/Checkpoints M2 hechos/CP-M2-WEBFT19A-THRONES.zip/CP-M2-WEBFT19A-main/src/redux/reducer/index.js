// Importa las actions types que necesites acá:


const initialState = {
    houses: [],
    house: {},
};

const rootReducer = (state = initialState, action) => {
    switch(action.type) {
        // Acá va tu código:
       
    };
};

export default rootReducer;
