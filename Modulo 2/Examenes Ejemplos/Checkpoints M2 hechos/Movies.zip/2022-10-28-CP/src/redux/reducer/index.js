// Importa las action types acá
import { GET_ALL_MOVIES } from 

const initialState = {
  movies: [],
  movieDetail: {},
  email: {},
};

const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    // Acá va tu código:
    case 

    default:
      return {...state}
  
  }
};

export default rootReducer;
