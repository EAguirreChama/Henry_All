"use strict";

var express = require("express");
const { listCategories, addCategory, listProducts, addProduct, getReviews, addReview, getRating } = require("../models/model");
const model = require("../models/model");


var router = express.Router();
module.exports = router;


const models = require("../models/model");


// escriban sus rutas acá
// siéntanse libres de dividir entre archivos si lo necesitan

router.get('/categories', (req, res) => {
    res.json(listCategories())
})

router.post('/categories', (req, res) => {
    const { category } = req.body
    // if(listCategories().includes(category))
    //     return res.status(400).json({ error: 'La categoría ya existe' })
    // // addCategory(category)
    // // return res.status(201).json({ msg: 'Categoría creada correctamente' })
    // if(addCategory(category)){
    //     return res.status(201).json({ msg: 'Categoría creada correctamente' })
    // }
   try {     
     res.status(201).json({ msg: addCategory(category) })
   } catch (error) {
        res.status(400).json({ error: 'La categoría ya existe' })
   }
})

router.get('/products', (req, res) => {
    const { category, fullName } = req.body
    res.json(listProducts(category, fullName))
})

router.post('/products', (req, res) => {
    const { name, brand, category, stock } = req.body
    try {
        res.status(201).json(addProduct(name, brand, category, stock))    
    } catch (error) {
        res.status(404).json({error: 'La categoría ingresada no existe'})
    }
    
})

router.get('/products/:categoryName', (req, res) => {    
    const { categoryName } = req.params
    const { fullName } = req.query
   try {
    res.json(listProducts(categoryName, fullName))    
   } catch (error) {
    res.status(404).json({ error: 'La categoría no existe' })
   }
})

router.get('/reviews', (req, res) => {    
    const { name } = req.query
   try {
    res.json(getReviews(name))    
   } catch (error) {
    res.status(404).json({ error: error.message })
   }
})

router.post('/reviews', (req, res) => {    
    const { name, stars, text, user } = req.body
   try {
    res.status(201).json({msg: addReview(name, stars, text, user)})    
   } catch (error) {
    res.status(400).json({ error: error.message })
   }
})

router.get('/rating', (req, res) => {    
    res.json(getRating())
})

router.get('/rating/:product', (req, res) => {    
    const { product } = req.params
    try {
        res.json({ rating: getRating(product) })
    } catch (error) {
        res.status(404).json({ error: error.message })        
    }
})