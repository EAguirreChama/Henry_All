const router = require('express').Router();
const classifyBooks = require('../controllers/06-controller')
// No modificar arriba de esta línea

/*
  1️⃣3️⃣ ***EJERCICIO 13*** GET /books/classified 1️⃣3️⃣
      ❕ CONSIGNA ❕
    1 - Integrar la función clsasifyBooks que desarrollaste previamente para clasificar los libros según el genero
    2 - Responder con el resultado de la operación junto a la fecha en que se solicitó (chequear bien el formato de ésta)
    📢 PUNTOS A TENER EN CUENTA 📢
    - Si algo falla al obtener los libros, debes responder con el status code pedido en el test con el mensaje del error!
*/

router.get('/books/classified', (req, res) => {
  try {
    const result = {
      books: classifyBooks(),
      requestDate: new Date().toLocaleDateString()
    };
    res.status(200).json(result)
  } catch (error) {
    res.status(500).json({message: error.message})
  }
})

// No modificar nada debajo de esta línea
module.exports = router;
